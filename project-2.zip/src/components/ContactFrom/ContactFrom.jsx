import { useState } from 'react';
import Button from '../Button/Button';
import {RiMessage3Fill} from 'react-icons/ri';
import {MdCall} from 'react-icons/md'
import {HiMail} from 'react-icons/hi';
import styles from './ContactFrom.module.css';

const ContactFrom = () => {

  const[name, setName] =useState('Nikhil');
  const[email, setEmail] =useState('reactcode@gmail.com');
  const[text, setText] =useState('Namaste React Js');

    const onSubmit = (event) => {
        event.preventDefault();
        // console.log(event);

        setName(event.target[0].value);
        setEmail(event.target[1].value);
        setText(event.target[2].value);
    }

    const viaSupportChat = () => {
        console.log("How can a Help You!");
    }

  return (
    <div>
      <section className={styles.container}>

        <div className={styles.contact_form}>
            <div className={styles.top_bar}>
            <Button onClick={viaSupportChat}
             text="VIA Support Chat" icon={<RiMessage3Fill fontSize="24px"/> }/>
            <Button text="VIA Call" icon={<MdCall fontSize="24px"/> }/>
            </div>
            <Button isOutline={true} 
            text="VIA Email Form" icon={<HiMail fontSize="24px"/> }/>


            <form onSubmit={onSubmit}>
                        <div className={styles.form_control}>
                            
                        <label htmlFor='name'>Name</label>
                        <input type="text" name='Name'/>
                        </div>
                <div className={styles.form_control}>
                    
                    <label htmlFor='email'>Email</label>
                    <input type="email" name='Email'/>
                </div>
                    <div className={styles.form_control}>
                    
                        <label htmlFor='text'>Message</label>
                        <textarea name='text' rows="10"/>
                    </div>
                    <div className={styles.submit_button}>
                    <button  text="Submit">Submit</button>
                    </div>
                    <div>{name + "" + email + "" + text }</div>
            </form>
        </div>
        <div className='{styles.contact_image}'>
            <img src='/Contact.svg' alt='Contact-image' />
        </div>
      </section>
    </div>
  )
}

export default ContactFrom;
