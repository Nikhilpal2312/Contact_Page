import  styles from './button.module.css';

const Button = ({isOutline, text, icon, ...rest}) => {
  return (
    <div {...rest} className=
    
    {isOutline  ? styles.outline_btn : styles.primary_btn}>
      {icon}
      {text}
      
    </div>
  )
}

export default Button;
