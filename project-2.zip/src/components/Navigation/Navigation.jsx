import styles from './Navigation.module.css'; 



const Navigation = () => {
  // console.log(styles)
  return (
    <div>
      <nav className={`${styles.navigation} container`}>
        <div className="Logo">
          <h3>Logo</h3>
        </div>
        <ul>
          <li href="#">Home</li>
          <li href="#">About</li>
          <li href="#">Contact</li>
        </ul>
      </nav>
    </div>
  )
}

export default Navigation;
