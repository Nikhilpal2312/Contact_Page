import React from 'react';
import './App.css'
import Navigation from './components/Navigation/Navigation';
import Hero from './components/Navigation/ContactHeader/ContactHeader';
import ContactFrom from './components/ContactFrom/ContactFrom';

function App() {

  return (
    <>
      <Navigation/>
      <main className='main_container'>
          <Hero />
          <ContactFrom/>
      </main>
    </>
  )
}

export default App
